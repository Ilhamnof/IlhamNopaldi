package id.ac.unand.fti.si.pbo;

public interface Member {
    
    void redeemPoin(Integer jumlahPoin);
    Integer getPoin();
}