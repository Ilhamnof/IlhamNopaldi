package id.ac.unand.fti.si.pbo;

public interface CanRequestDelivery {

    Double hitungOngkir(Double jarak);
}