package id.ac.unand.fti.si.pbo;

public interface CanRequestCicilan {
  Integer hitungCicilanPerBulan(Integer amount, Integer time);

}
