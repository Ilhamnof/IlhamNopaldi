package id.ac.unand.fti.si.pbo;

public interface CanGetDiskon {
  Integer hitungTotalBayar(Integer jumlah);
}
