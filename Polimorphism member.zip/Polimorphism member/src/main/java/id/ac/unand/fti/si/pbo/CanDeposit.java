package id.ac.unand.fti.si.pbo;

public interface CanDeposit {
  void deposit(Integer amount);
  void tarikTunai(Integer amount);
}
